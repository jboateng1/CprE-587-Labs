#include <iostream>

using namespace std;

int main() {
    std::cout<<"Print"<<"\n";

    return 0;
}